import entity.Pessoa;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

public class Main {
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa("Sarah","Sabongi","sarah@njjd");
        Pessoa p2 = new Pessoa("Bia","Alves","alves@njjd");
        Pessoa p3 = new Pessoa("Kaio","Luiz","luiz@njjd");
        Pessoa p4 = new Pessoa("Elisa","Teixeira","elisa@njjd");

        Session session = HibernateUtil.getSessionFactory().openSession(); //pega uma sessao e abre ela

        Transaction transaction = session.beginTransaction(); //pegando minha sessao e iniciando uma transação

        session.persist(p1);
        session.persist(p2);
        session.persist(p3);
        session.persist(p4);

        transaction.commit();
    }
}
